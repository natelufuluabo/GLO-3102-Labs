<script setup>
import LoginSignUp from '@/components/LoginSignUp.vue'
</script>
<template>
  <LoginSignUp />
</template>
