<script setup>
import Weather from '@/components/Weather.vue'
import AppInterface from '@/components/AppInterface.vue'
</script>
<template>
  <Weather />
  <AppInterface />
</template>
